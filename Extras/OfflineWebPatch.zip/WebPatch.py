with open("index.html", "r") as file:
    content = file.read().replace("</style>", "</style><script src=\"./elestub.js\"></script>")

with open("index.html", "w") as file:
    file.write(content)
