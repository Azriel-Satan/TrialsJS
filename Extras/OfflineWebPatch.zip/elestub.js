/**
 * stub electronAPI, pretend everything is fiiine
 * allows playing electron version in a browser of your choice
 * pretends image pack is installed, doesn't actually check if it is
 * use electron launcher to actually manage image pack (or do it manually)
 */

(function eleStub() {
	const debug = false;
	if (!window.electronAPI) {
		window.electronAPI = {
			async checkManifest(...args) {if (debug) console.log("checkManifest stub!", ...args); return true}, // fake successful manifest check
			async notifyHasImagesAvailable(callback){if (debug) console.log("notifyHasImagesAvailable", callback); await imagesInstalled(); callback(0, 0)}, // notify there's 0 images need updating

			async downloadImages(...args) {if (debug) console.log("downloadImages stub!", ...args); return false}, // false == no downloads needed
			async notifyDownloadProgress(callback) {if (debug) console.log("notifyDownloadProgress stub!", callback)}, // successfully downloaded nothing
			async downloadImagesCancel(...args) {if (debug) console.log("downloadImagesCancel stub!", ...args)}, // this does nothing while no dls active
			async notifyDownloadComplete(callback) {if (debug) console.log("notifyDownloadComplete stub!", callback)}, // is done

			async clearImages(...args) {if (debug) console.log("clearImages stub!", ...args)}, // yeah, no.
			async installImages(...args) {if (debug) console.log("installImages stub!", ...args); return true}, // yeah, yeah
			async hasImagesInstalled(...args) {if (debug) console.log("hasImagesInstalled stub!", ...args); return true}, // yeah x4
			async notifyHasImagesInstalled(callback) {if (debug) console.log("notifyHasImagesInstalled stub!", callback)}, // yeah, yeah, yeah

			onTriggerRedraw(...args) {if (debug) console.log("onTriggerRedraw stub!", ...args)}, // no idea what it does
			forceReload(...args) {if (debug) console.log("forceReload stub!", ...args)}, // this doesn't work either way
		}
		window.imagesInstalled = async () => {await setTimeout(()=>true, 1000); return window.electronAPI.hasImagesInstalled()};
	};
})()

